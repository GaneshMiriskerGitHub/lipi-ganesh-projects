package com.imdb.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.entity.dto.MovieDTO;
import com.imdb.repository.MovieRepository;

@Service
public class MovieService {
	
	@Autowired
	MovieRepository movieRepository;
	

	public String addMovie(@RequestBody MovieDTO movieDTO) throws Exception {
		return movieRepository.addMovie(movieDTO);
	}


	public List<MovieDTO> getAllMovies() throws Exception {
		return movieRepository.getAllMovies();
	}

	
	public MovieDTO getMovieById(Integer id) throws Exception {
		return movieRepository.getMovieById(id);
	}

	
	public String deleteMovieById(Integer id) throws Exception {
		return movieRepository.deleteMovieById(id);
	}

	
	public String updateMovie(@RequestBody MovieDTO movieDTO) throws Exception {
		return movieRepository.updateMovie(movieDTO);
	}


	public List<MovieDTO> getMovieByTitle(String title) throws Exception {
		return movieRepository.getMovieByTitle(title);
	}

	
	
}
