package com.imdb.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;

import com.imdb.dto.MovieDTO;

/*
 DB Scripts 
 
 drop database if exists imdb_database;
create database imdb_database;
use imdb_database;

create table movie_table (

   id int primary key auto_increment,
   title varchar(50),
   genre varchar(20),
   rating decimal(3, 1)

);


select * from movie_table;
desc movie_table;


 */

@Repository
public class MovieRepository {

	public String addMovie(@RequestBody MovieDTO movieDTO) throws ClassNotFoundException, SQLException   {
		
		System.out.println("********* repositry class ***********");

		// Step 1
		Class.forName("com.mysql.cj.jdbc.Driver");

		// Step 2
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/imdb_database", "root", "4935");

		// Step 3
		String query = "INSERT INTO MOVIE_TABLE(title, genre, rating) values(?, ?, ?)";
		PreparedStatement st = con.prepareStatement(query);
		st.setString(1, movieDTO.getTitle());
		st.setString(2, movieDTO.getGenre());
		st.setDouble(3, movieDTO.getRating());

		int rowsAffected = st.executeUpdate();

		return "New Movie successfully added";

	}

	public List<MovieDTO> getAllMovies() throws Exception {

		List<MovieDTO> movieDtoList = new ArrayList<>();

		// Step 1
		Class.forName("com.mysql.cj.jdbc.Driver");

		// Step 2
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/imdb_database", "root", "4935");

		// Step 3
		String query = "select * from MOVIE_TABLE";
		PreparedStatement st = con.prepareStatement(query);

		System.out.println(query);

		ResultSet rs = st.executeQuery();

		// Process the results
		while (rs.next()) {
			MovieDTO dto = new MovieDTO();
			dto.setId(rs.getInt("id"));
			dto.setTitle(rs.getString("title"));
			dto.setGenre(rs.getString("genre"));
			dto.setRating(rs.getDouble("rating"));
			movieDtoList.add(dto);
		}

		return movieDtoList;
	}

	public MovieDTO getMovieById(Integer id) throws Exception {

		List<MovieDTO> movieDtoList = new ArrayList<>();

		// Step 1
		Class.forName("com.mysql.cj.jdbc.Driver");

		// Step 2
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/imdb_database", "root", "4935");

		// Step 3
		String query = "select * from MOVIE_TABLE where id = ?";
		PreparedStatement st = con.prepareStatement(query);

		st.setInt(1, id);

		System.out.println(query);

		ResultSet rs = st.executeQuery();

		// Process the results
		while (rs.next()) {
			MovieDTO dto = new MovieDTO();
			dto.setId(rs.getInt("id"));
			dto.setTitle(rs.getString("title"));
			dto.setGenre(rs.getString("genre"));
			dto.setRating(rs.getDouble("rating"));
			movieDtoList.add(dto);
		}

		return movieDtoList.get(0);

	}

	public String deleteMovieById(Integer id) throws Exception {
		// Step 1
		Class.forName("com.mysql.cj.jdbc.Driver");

		// Step 2
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/imdb_database", "root", "4935");

		// Step 3
		String query = "Delete From MOVIE_TABLE where id = ?";
		PreparedStatement st = con.prepareStatement(query);
		st.setInt(1, id);

		int rowsAffected = st.executeUpdate();

		return "movie deleted";
	}

	public String updateMovie(@RequestBody MovieDTO movieDTO) throws Exception {

		// Step 1
		Class.forName("com.mysql.cj.jdbc.Driver");

		// Step 2
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/imdb_database", "root", "4935");

		// Step 3
		String query = "UPDATE MOVIE_TABLE SET title = ?, genre = ?, rating = ? where id = ?";
		PreparedStatement st = con.prepareStatement(query);
		st.setString(1, movieDTO.getTitle());
		st.setString(2, movieDTO.getGenre());
		st.setDouble(3, movieDTO.getRating());

		int rowsAffected = st.executeUpdate();

		return "movie successfully updated";

	}

	public List<MovieDTO> getMovieByTitle(String title) throws Exception {

		List<MovieDTO> movieDtoList = new ArrayList<>();

		// Step 1
		Class.forName("com.mysql.cj.jdbc.Driver");

		// Step 2
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/imdb_database", "root", "4935");

		// Step 3
		String query = "select * from MOVIE_TABLE where title = ?";
		PreparedStatement st = con.prepareStatement(query);

		st.setString(1, title);

		System.out.println(query);

		ResultSet rs = st.executeQuery();

		// Process the results
		while (rs.next()) {
			MovieDTO dto = new MovieDTO();
			dto.setId(rs.getInt("id"));
			dto.setTitle(rs.getString("title"));
			dto.setGenre(rs.getString("genre"));
			dto.setRating(rs.getDouble("rating"));
			movieDtoList.add(dto);
		}

		return movieDtoList;
	}

}
